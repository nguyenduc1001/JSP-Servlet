/**
 * 
 */
package com.tuan.dao;

import java.util.List;

import com.tuan.model.Car;

/**
 * @author Tuan
 *
 */
public interface CarDAO {
        List<Car> getAllListCar();
}
