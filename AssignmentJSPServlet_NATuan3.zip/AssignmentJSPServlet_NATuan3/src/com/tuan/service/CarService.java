/**
 * 
 */
package com.tuan.service;

import java.util.List;

import com.tuan.model.Car;

/**
 * @author Tuan
 *
 */
public interface CarService {
        List<Car> getAllListCar();
}
